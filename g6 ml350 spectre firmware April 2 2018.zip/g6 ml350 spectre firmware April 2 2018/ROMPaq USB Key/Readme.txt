HPE USB Key Setup Utility
=========================

HPEUSB.exe - Windows-based utility to locally partition, format and copy necessary files to
a USB flash media device through the Windows environment.


HOW TO USE:
  
     1. Close all other applications before launching HPE USB Key Setup Utility.

     2. Obtain a formatted USB media key and place it in the USB port.     
          
     3. Double-click on the file HPEUSB.EXE and follow the instructions to complete 
        the preparation of the USB flash media device.      
 	
     4. Place the newly created USB flash media device into the server to be updated or
        restored and cycle system power to boot from the USB flash media device.

     5. Follow the on-screen instructions to select the system ROM and flash the 
        firmware.


WARNING:  DO NOT TURN OFF POWER OR ATTEMPT TO REBOOT THE COMPUTER DURING THE UPDATE PROCESS!!!




� Copyright 1982 - 2018 Hewlett Packard Enterprise Development LP 



