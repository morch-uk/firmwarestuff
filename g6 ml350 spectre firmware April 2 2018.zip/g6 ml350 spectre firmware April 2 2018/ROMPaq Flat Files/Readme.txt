ROMPaq Flat Files
=================


Flat files are provided as a convenience to customers who have established a method to update or restore the BIOS on their server(s). As there are multiple methods to accomplish this, the availability of these flat files bundled up in a single directory facilitates the copy/paste process. These flat files can be easily copied to a destination folder without having the need to extract them. This saves you time and ensures a complete file set of supported files for the server's BIOS upgrade or restore process.




Product Name                      System ROM             Image Name

----------------------------------------------------------------------

HP ProLiant ML350 G6 Servers         D22                CPQD220x.xxx

Files included in this folder:


ROMPAQ.EXE
Readme.txt
Readme.1st
xxxxxxxx.CPU
CPQxxxxx.xxx




Copyright � 2018 Hewlett Packard Enterprise.  All rights reserved.

